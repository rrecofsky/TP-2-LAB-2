//  ATMegaServiceMain.cpp
//

#include "stdafx.h"
#include "auxfunctions.h"

#pragma warning(disable:4996) //disable warnings due to ANSI C string functions

///////////////////////////////////////////////////////////////////////////////
// PAY ATTENTION: You will see the service declaration below these remark lines.
// The only reuirement to develop a service based upon this source code 
// consists in having the same SERVICE_NAME that EXE file generated.
// In this specific sample:
//   1. "ATMegaService" is the SERVICE_NAME and...
//   2. "ATMegaService.EXE" is the executable filename.
// This rule is required because we will use GetModuleFileName to guess the 
// EXE filename in order to:
//   1. Point the service itself getting the file name from the operating system.
//   2. Generate a valid filename for the log file.
// See source code in the current cpp file and the auxfunctions.cpp file.
// 
#define SERVICE_NAME "ATMegaService"

//Forward function declarations:
void ExecuteNormalProcess();
void SecondThread(VOID *);

//Externally accessed functions specific for all Windows Services:
void WINAPI ServiceMain(DWORD dwArgc, LPTSTR *lpszArgv);
void WINAPI ServiceHandler(DWORD fdwControl);

//Global variables:
CRITICAL_SECTION myCS;
char lpCmdLineData[BUFFER_SIZE+1];
BOOL bProcessStarted = TRUE;

char szServiceName[BUFFER_SIZE+1];

SERVICE_TABLE_ENTRY		lpServiceStartTable[] = 
{
	{szServiceName, ServiceMain},
	{NULL, NULL}
};

SERVICE_STATUS_HANDLE   hServiceStatusHandle; 
SERVICE_STATUS          ServiceStatus; 

///////////////////////////////////////////////////////////////////////////////
// This is the main entry point for a console application, no matter when it
// is called either by the operating system (boot) or by a command line prompt.
// It receives two parameters:
//
// 1. argc is the argument counter, i.e., the number of command line parameters.
// 2. argv[] is the array of command line parameters being received.
//
int _tmain(int argc, _TCHAR* argv[])
{
	char szTemp[200];

	::InitializeCriticalSection(&myCS);

	memset(szTemp, 0, sizeof(szTemp));
	WriteLog("[M]_tmain: main program entry point--------------------");
	if(argc >= 2)
	{
		strcpy(lpCmdLineData, argv[1]);
		sprintf(szTemp, "[M]_tmain: command line contains parameter %s", argv[1]);
		WriteLog(szTemp);
	}
	ServiceMainProc();
	return 0;
}

///////////////////////////////////////////////////////////////////////////////
// This function is called from _tmain and chooses what does the main thread do
// depending on the way that the EXE is started.
// You can start it from command line. In this case, the lpCmdLineData contains
// the parameter provided from command line.
// This command line parameter lauches tasks that require admin rights,
// so the cmd command line prompt must be called using "as administrator".
// These command line parameters can be one of the following:
//   -i to auto-install the service ....(requires admin rights).
//   -s to start the service ...........(also requires admin rights).
//   -k to kill (stop) the service .....(also requires admin rights).
//   -u to auto-UNinstall the service ..(also requires admin rights).
// There is no need to change nothing to write different services 
// having different names, since we guess the service name via GetModuleFileName 
// API function from Windows, no mtter which EXE file name is.
// The only limitation is that the service name must match the EXE filename.
//
void ServiceMainProc()
{
	// initialize variables for .exe and .log file names
	char szTemp[200];
	char szExeFile[BUFFER_SIZE+1];

	memset(szTemp, 0, sizeof(szTemp));

	DWORD dwSize = GetModuleFileName(NULL, szExeFile, BUFFER_SIZE);
	szExeFile[dwSize] = 0;
	
	strcpy(szServiceName, SERVICE_NAME);
	sprintf(szTemp, "[M]ServiceMainProc: SERVICE_NAME = %s", szServiceName);
	WriteLog(szTemp);

	if(_stricmp("-i",lpCmdLineData) == 0 || _stricmp("-I",lpCmdLineData) == 0)
		Install(szExeFile, szServiceName);
	else if(_stricmp("-k",lpCmdLineData) == 0 || _stricmp("-K",lpCmdLineData) == 0)
		KillService(szServiceName);
	else if(_stricmp("-u",lpCmdLineData) == 0 || _stricmp("-U",lpCmdLineData) == 0)
		UnInstall(szServiceName);
	else if(_stricmp("-s",lpCmdLineData) == 0 || _stricmp("-S",lpCmdLineData) == 0)
		RunService(szServiceName);
	else
		ExecuteNormalProcess();
}

///////////////////////////////////////////////////////////////////////////////
// This function is called from ServiceMainProc when no command line is used, 
// i.e., when the command line argument counter is lesser than 2, 
// so it means that is is the normal process for a service.
// It basically performs two tasks:
//   1. It starts the Second Thread via _beginThread function.
//   2. It starts the Service Control dispatcher.
//

void ExecuteNormalProcess()
{
	long nError = 0;
	char szTemp[200];

	//Start the second thread that contains the real action, the purpose.
	if(_beginthread(SecondThread, 0, NULL) == -1)
	{
		nError = GetLastError();
		sprintf(szTemp, "Could not start SecondThread via _beginthread, error code = %d\n", nError);
		WriteLog(szTemp);
	}
	
	//Activate the service control dispatcher:
	if(!StartServiceCtrlDispatcher(lpServiceStartTable))
	{
		nError = GetLastError();
		sprintf(szTemp, "StartServiceCtrlDispatcher failed, error code = %d\n", nError);
		WriteLog(szTemp);
	}
	::DeleteCriticalSection(&myCS);
}

///////////////////////////////////////////////////////////////////////////////
// The first execution of the service in a day is accomplished by the
// ServiceMain function. 
// This is an exportable Windows function that can be seen from outside the 
// service, so, the Windows Service Manager can work with it.
// Every service must have this function.
// It registers the service control handler as "start pending" and then
// it sets the service status to running.
//

void WINAPI ServiceMain(DWORD dwArgc, LPTSTR *lpszArgv)
{
	DWORD   status = 0; 
    DWORD   specificError = 0xfffffff; 
	long nError = 0;
	char szTemp[200];
 
    ServiceStatus.dwServiceType        = SERVICE_WIN32; 
    ServiceStatus.dwCurrentState       = SERVICE_START_PENDING; 
    ServiceStatus.dwControlsAccepted   = SERVICE_ACCEPT_STOP | SERVICE_ACCEPT_SHUTDOWN | SERVICE_ACCEPT_PAUSE_CONTINUE; 
    ServiceStatus.dwWin32ExitCode      = 0; 
    ServiceStatus.dwServiceSpecificExitCode = 0; 
    ServiceStatus.dwCheckPoint         = 0; 
    ServiceStatus.dwWaitHint           = 0; 
 
    hServiceStatusHandle = RegisterServiceCtrlHandler(szServiceName, ServiceHandler); 
    if (hServiceStatusHandle==0) 
    {
		nError = GetLastError();
		sprintf(szTemp, "RegisterServiceCtrlHandler failed, error code = %d\n", nError);
		WriteLog(szTemp);
        return; 
    } 
 
    // Initialization complete - report running status 
    ServiceStatus.dwCurrentState       = SERVICE_RUNNING; 
    ServiceStatus.dwCheckPoint         = 0; 
    ServiceStatus.dwWaitHint           = 0;  
    if(!SetServiceStatus(hServiceStatusHandle, &ServiceStatus)) 
    { 
		nError = GetLastError();
		sprintf(szTemp, "SetServiceStatus failed, error code = %d\n", nError);
		WriteLog(szTemp);
    } 
}

///////////////////////////////////////////////////////////////////////////////
// This is the handler for Start, Stop, Pause, Continue service commands.
// This is another required exportable function for every service.
// This handler is used by the Service Manager application from Windows
// and can be also called by other services that programatically require  
// another services to be running.
// Remarks: This function is called by the Service Manager application,
// via Windows API calls, not by the command line.
//
void WINAPI ServiceHandler(DWORD fdwControl)
{
	int i =0;
	long nError = 0;
	char szTemp[200];

	switch(fdwControl) 
	{
		case SERVICE_CONTROL_STOP:
		case SERVICE_CONTROL_SHUTDOWN:
			bProcessStarted = FALSE;
			ServiceStatus.dwWin32ExitCode = 0; 
			ServiceStatus.dwCurrentState  = SERVICE_STOPPED; 
			ServiceStatus.dwCheckPoint    = 0; 
			ServiceStatus.dwWaitHint      = 0;
			
			// Deallocate other resources, close other handles...
			WriteLog("[M]Stopping service.");
			break; 
		case SERVICE_CONTROL_PAUSE:
			ServiceStatus.dwCurrentState = SERVICE_PAUSED; 
			break;
		case SERVICE_CONTROL_CONTINUE:
			ServiceStatus.dwCurrentState = SERVICE_RUNNING; 
			break;
		case SERVICE_CONTROL_INTERROGATE:
			break;
		default:
			if(!(fdwControl>=128&&fdwControl<256))
			{
				sprintf(szTemp,  "Unknown service message %d\n", fdwControl);
				WriteLog(szTemp);
			}
	};
    if (!SetServiceStatus(hServiceStatusHandle,  &ServiceStatus)) 
	{ 
		nError = GetLastError();
		sprintf(szTemp, "SetServiceStatus failed, error code = %d\n", nError);
		WriteLog(szTemp);
    } 
}

///////////////////////////////////////////////////////////////////////////////
// SECOND THREAD
// This is the real action thread, the thread performing the backgroud tasks
// of controlling: the real purpose of creating the service.
//
// **** This is the point where you must place your functionality. ****
//
void SecondThread(VOID *)
{
	char szTemp[200];

	bProcessStarted = TRUE;
	memset(szTemp, 0, sizeof(szTemp));

	while(bProcessStarted == TRUE)
	{
		//Default functionality consists in logging a text line
		//every 3 seconds:
		sprintf(szTemp, "[S]SecondThread: Loop.", szServiceName);
		WriteLog( szTemp);

		Sleep(3000); //Sleep 3 seconds before next loop
	}
}
