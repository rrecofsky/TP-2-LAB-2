// stdafx.h : include file for standard system include files,
// or project specific include files that are used frequently, but
// are changed infrequently
//

#pragma once

#if _MSC_VER >= 1000
#pragma once
#endif // _MSC_VER >= 1000

#define VC_EXTRALEAN		// Exclude rarely-used stuff from Windows headers

#ifndef _WIN32_IE
#define _WIN32_IE 0x0500    // enable shell v5 features
#elif _WIN32_IE < 0x0500
#undef _WIN32_IE
#define _WIN32_IE 0x0500    // enable shell v5 features
#endif

#include <afxwin.h>         // MFC core and standard components
#include <afxext.h>         // MFC extensions
#include <afxdisp.h>        // MFC OLE automation classes
#ifndef _AFX_NO_AFXCMN_SUPPORT
#include <afxcmn.h>			// MFC support for Windows Common Controls
#endif // _AFX_NO_AFXCMN_SUPPORT


// TODO: reference additional headers your program requires here
#include <process.h>
#include <iostream>
#include <tchar.h>
#include <stdio.h>
//#include <windows.h>
#include <winbase.h>
#include <winsvc.h>