//Header file for auxiliary functions:

#include "stdafx.h"

#ifndef _AUXFUNCTIONS_
#define _AUXFUNCTIONS_

#define BUFFER_SIZE 500			//Buffer size for long strings
extern CRITICAL_SECTION myCS;

/** Functions **/
VOID WriteLog(CHAR* pMsg);
VOID ServiceMainProc();
VOID Install(char* pPath, char* pName);
VOID UnInstall(char* pName);
BOOL KillService(char* pName);
BOOL RunService(char* pName);

#endif

