// Auxiliary functions for the service:

#include "stdafx.h"
#include <iostream>			// Use of cin, cout streams
#include "auxfunctions.h"

#pragma warning(disable:4996) //disable warnings due to ANSI C string functions

void WriteLog(char * lpszMsg)
{
	char szModuleFile[BUFFER_SIZE+1];
	char szLogFile[BUFFER_SIZE+1];
	char szExeFile[BUFFER_SIZE+1];
	DWORD dwSize;

	::EnterCriticalSection(&myCS);

	dwSize = GetModuleFileName(NULL, szModuleFile, BUFFER_SIZE);
	szModuleFile[dwSize] = 0;
	if(dwSize>4 && szModuleFile[dwSize-4] == '.')
	{
		sprintf(szExeFile,"%s",szModuleFile);
		szModuleFile[dwSize-4] = 0;
		sprintf(szLogFile,"%s.log",szModuleFile);
	}

	try
	{
		SYSTEMTIME oT;
		::GetLocalTime(&oT);
		FILE* pLog = fopen(szLogFile,"a");
		fprintf(pLog,"%02d/%02d/%04d, %02d:%02d:%02d\t    %s\r\n",oT.wMonth,oT.wDay,oT.wYear,oT.wHour,oT.wMinute,oT.wSecond,lpszMsg); 
		fclose(pLog);
	} catch(...) {}
	::LeaveCriticalSection(&myCS);
}

void Install(char* lpszFileName, char* lpszServiceName)
{  
	long nError = 0;
	char szTemp[200];

	SC_HANDLE schSCManager = OpenSCManager( NULL, NULL, SC_MANAGER_CREATE_SERVICE); 
	if (schSCManager==0) 
	{
		nError = GetLastError();
		sprintf(szTemp, "[M]Install: OpenSCManager failed, error code = %d\n", nError);
		WriteLog(szTemp);
		WriteLog("[M]Install: Maybe your command prompt has no rights as administrator?");
	}
	else
	{
		SC_HANDLE schService = CreateService
		( 
			schSCManager,			/* SCManager database      */ 
			lpszServiceName,		/* name of service         */ 
			lpszServiceName,		/* service name to display */ 
			SERVICE_ALL_ACCESS,		/* desired access          */ 
			SERVICE_WIN32_OWN_PROCESS|SERVICE_INTERACTIVE_PROCESS , /* service type            */ 
			SERVICE_AUTO_START,     /* start type              */ 
			SERVICE_ERROR_NORMAL,   /* error control type      */ 
			lpszFileName,			/* service's binary        */ 
			NULL,                   /* no load ordering group  */ 
			NULL,                   /* no tag identifier       */ 
			NULL,                   /* no dependencies         */ 
			NULL,                   /* LocalSystem account     */ 
			NULL					/* no password             */ 
		);                     
		if (schService==0) 
		{
			nError =  GetLastError();
			sprintf(szTemp, "[M]Install: Failed to create service %s, error code = %d\n", lpszServiceName, nError);
			WriteLog(szTemp);
			WriteLog("[M]Install:Maybe your command prompt has no rights as administrator?");
		}
		else
		{
			sprintf(szTemp, "[M]Install: Service %s installed\n", lpszServiceName);
			WriteLog(szTemp);
			CloseServiceHandle(schService); 
		}
		CloseServiceHandle(schSCManager);
	}	
}

void UnInstall(char* lpszServiceName)
{
	long nError = 0;
	char szTemp[200];

	SC_HANDLE schSCManager = OpenSCManager( NULL, NULL, SC_MANAGER_ALL_ACCESS); 
	if (schSCManager==0) 
	{
		nError = GetLastError();
		sprintf(szTemp, "[M]UnInstall: OpenSCManager failed, error code = %d\n", nError);
		WriteLog(szTemp);
		WriteLog("[M]UnInstall: Maybe your command prompt has no rights as administrator?");
	}
	else
	{
		SC_HANDLE schService = OpenService( schSCManager, lpszServiceName, SERVICE_ALL_ACCESS);
		if (schService==0) 
		{
			nError = GetLastError();
			sprintf(szTemp, "[M]UnInstall: OpenService failed, error code = %d\n", nError);
			WriteLog(szTemp);
			WriteLog("[M]UnInstall: Maybe your command prompt has no rights as administrator?");
		}
		else
		{
			if(!DeleteService(schService)) 
			{
				sprintf(szTemp, "[M]UnInstall: Failed to delete service %s\n", lpszServiceName);
				WriteLog(szTemp);
				WriteLog("[M]UnInstall: Maybe your command prompt has no rights as administrator?");
			}
			else 
			{
				sprintf(szTemp, "[M]UnInstall: Service %s removed\n", lpszServiceName);
				WriteLog(szTemp);
			}
			CloseServiceHandle(schService); 
		}
		CloseServiceHandle(schSCManager);	
	}
}

BOOL KillService(char* lpszServiceName) 
{ 
	long nError = 0;
	char szTemp[200];

	// kill service with given name
	SC_HANDLE schSCManager = OpenSCManager( NULL, NULL, SC_MANAGER_ALL_ACCESS); 
	if (schSCManager==0) 
	{
		nError = GetLastError();
		sprintf(szTemp, "[M]KillService: OpenSCManager failed, error code = %d\n", nError);
		WriteLog(szTemp);
		WriteLog("[M]KillService: Maybe your command prompt has no rights as administrator?");
	}
	else
	{
		// open the service
		SC_HANDLE schService = OpenService( schSCManager, lpszServiceName, SERVICE_ALL_ACCESS);
		if (schService==0) 
		{
			nError = GetLastError();
			sprintf(szTemp, "[M]KillService: OpenService failed, error code = %d\n", nError);
			WriteLog(szTemp);
			WriteLog("[M]KillService: Maybe your command prompt has no rights as administrator?");
		}
		else
		{
			// call ControlService to kill the given service
			SERVICE_STATUS status;
			if(ControlService(schService,SERVICE_CONTROL_STOP,&status))
			{
				CloseServiceHandle(schService); 
				CloseServiceHandle(schSCManager); 
				WriteLog("[M]KillService: Service stopped.\n");
				return TRUE;
			}
			else
			{
				nError = GetLastError();
				sprintf(szTemp, "[M]KillService: ControlService failed, error code = %d\n", nError);
				WriteLog(szTemp);
				WriteLog("[M]KillService: Maybe your command prompt has no rights as administrator?");
			}
			CloseServiceHandle(schService); 
		}
		CloseServiceHandle(schSCManager); 
	}
	return FALSE;
}

BOOL RunService(char* lpszServiceName) 
{ 
	long nError = 0;
	char szTemp[200];

	// run service with given name
	SC_HANDLE schSCManager = OpenSCManager( NULL, NULL, SC_MANAGER_ALL_ACCESS); 
	if (schSCManager==0) 
	{
		nError = GetLastError();
		sprintf(szTemp, "[M]RunService: OpenSCManager failed, error code = %d\n", nError);
		WriteLog(szTemp);
		WriteLog("[M]RunService: Maybe your command prompt has no rights as administrator?");
	}
	else
	{
		// open the service
		SC_HANDLE schService = OpenService( schSCManager, lpszServiceName, SERVICE_ALL_ACCESS);
		if (schService==0) 
		{
			nError = GetLastError();
			sprintf(szTemp, "[M]RunService: OpenService failed, error code = %d\n", nError);
			WriteLog(szTemp);
			WriteLog("[M]RunService: Maybe your command prompt has no rights as administrator?");
		}
		else
		{
			// call StartService to run the service
			if(StartService(schService, 0, (const char**)NULL))
			{
				CloseServiceHandle(schService); 
				CloseServiceHandle(schSCManager); 
				strcpy(szTemp, "[M]RunService: Service running.\n");
				WriteLog(szTemp);
				return TRUE;
			}
			else
			{
				nError = GetLastError();
				sprintf(szTemp, "[M]RunService: StartService failed, error code = %d\n", nError);
				WriteLog(szTemp);
				WriteLog("[M]RunService: Maybe your command prompt has no rights as administrator?");
			}
			CloseServiceHandle(schService); 
		}
		CloseServiceHandle(schSCManager); 
	}
	return FALSE;
}
